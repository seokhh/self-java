package sec02.exam02;

public class ChildExample {
    public static void main(String[] args){
        Child child = new Child();

        Parent parent = child;
        parent.method1();
        parent.method2(); //오버라이딩된 메서드가 호출됨 method2가 이미 Child에 선언되었기 때문
        //parent.method3();
        //Child 클래스에서 따로 생성된 것이기 때문에 부모클래스로 자동타입변환되어서 호출 불가능
    }
}
