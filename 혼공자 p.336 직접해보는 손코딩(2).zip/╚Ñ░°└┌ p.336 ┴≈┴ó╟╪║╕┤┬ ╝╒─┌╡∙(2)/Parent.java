package sec02.exam02;

public class Parent {
    public void method1() {
        System.out.println("Parent-method1()");
    }

    public void method2(){
        System.out.println("Parnet-method2()");
    }
}
