public class Main {
    public static void main(String[] args) {
        String doc = "프린터로 출력을 합니다";
        Printable prn1 = new PrnDrvSamsung();
        prn1.print(doc);
        Printable prn2 = new PrnDrvEpson();
        prn2.print(doc);
    }
}
