interface Printable {
    void print(String doc);
}
