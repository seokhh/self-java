class PrnDrvSamsung implements Printable {
    public void print(String doc) {
        System.out.println(doc + "\n from Samsung");
    }
}
