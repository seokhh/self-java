import java.util.*;
public class Car {

    Scanner sc = new Scanner(System.in);
        String company = sc.nextLine();

        String model = sc.nextLine();
        String color = sc.nextLine();
        int maxSpeed = sc.nextInt();
        int speed = sc.nextInt();
}
