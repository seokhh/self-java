public class FieldInitValue {
    byte byteField;
    short shortField;
    int intField;
    long longField;

    boolean BooleanField;
    char charField;

    float floatField;
    double doubleField;

    int[] arrField;
    String stringField;
}
