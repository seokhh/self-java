/* 빈칸에 알맞은 코드를 적어보시오*/
public class Main {
    public static void main(String[] args) {
        Member member = /*빈칸*/new Member();
        System.out.println("이름: " + member.name);
        System.out.println("나이: " + member.age);
        
        /*빈칸*/ member.name = "최하얀";
        /*빈칸*/ member.age = 23; //name와 age값 변경

        System.out.println("이름: " + member.name);
        System.out.println("나이: " + member.age);
    }
}