import java.util.*;
public class Member {
    String name;
    int age;
}
