public class Car {
    String color;
    int cc;
    Car(String colors, int ccs){
        color = colors;
        cc = ccs;
    }
}
