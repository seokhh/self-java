public class Car {

    Car(String color, int cc){
        System.out.println(color);
        System.out.println(cc);
        System.out.println(color+"색의 " + cc + "cc 자동차가 생성됨");
    }
}
