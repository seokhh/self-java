public class Main {
    public static void main(String[] args) {
        Car mycar = new Car("검정", 1000);

    }
}