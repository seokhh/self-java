public class Main {
    public static void main(String[] args) {
        Car mycar = new Car("검정", 1000);
        System.out.println("색깔: " + mycar.color);
        System.out.println("CC: "  + mycar.cc);
    }
}