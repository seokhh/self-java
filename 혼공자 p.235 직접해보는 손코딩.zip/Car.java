public class Car {

    Car(String color, int cc){}
}