public class CarExample {

    public static void main(String[] args) {
        Car mycar = new Car("검정", 3000);
        
    }
}