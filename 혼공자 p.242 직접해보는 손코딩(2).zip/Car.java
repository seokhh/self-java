public class Car {
    String company = "현대자동차";
    String model;
    String color;
    int maxSpeed;

    Car(){
        //이 생성자는 기본 값으로 된 클래스가 생성됨
    }

    Car(String model){
        this(model, null, 0);
    }

    Car(String model, String color){
        this(model, color, 0);
    }

    Car(String model, String color, int maxSpeed){
        this.model = model;
        this.color = color;
        this.maxSpeed = maxSpeed;
    }
}
