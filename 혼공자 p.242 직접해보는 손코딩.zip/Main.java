public class Main {

    public static void main(String[] args) {
        Car car1 = new Car();
        System.out.println("car1.company : "+ car1.company);
        System.out.println();

        Car car2 = new Car("아반떼");
        System.out.println("car2.company : "+ car2.company);
        System.out.println("car2.model : "+ car2.model);
        System.out.println("car2.color : "+car2.color);
        System.out.println();

        Car car3 = new Car("소나타", "흰색");
        System.out.println("car3.company : "+ car3.company);
        System.out.println("car3.model : "+ car3.model);
        System.out.println("car3.color : "+car3.color);
        System.out.println();

        Car car4 = new Car("그랜저", "노란색", 250);
        System.out.println("car4.company : "+ car4.company);
        System.out.println("car4.model : "+ car4.model);
        System.out.println("car4.color : "+car4.color);
        System.out.println("car4.maxspeed : "+car4.maxspeed);
    }
}