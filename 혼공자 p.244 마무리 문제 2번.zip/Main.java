/* Member 객체를 생성하는데 외부에서 값을 받을 수 있게 클래스를 생성해보시오*/
public class Main {
    public static void main(String[] args) {
        Member member = new Member("홍길동", "hong");
        System.out.println("이름: " + member.name);
        System.out.println("ID: " + member.id);
    }
}