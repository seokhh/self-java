public class Member {
    String name;
    String id;

    Member(String name, String id){
        this.name = name;
        this.id = id;
    }
}
