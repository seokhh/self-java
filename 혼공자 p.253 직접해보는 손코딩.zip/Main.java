public class Main {
    public static void main(String[] args) {
        Calculator clac = new Calculator();
        clac.powerOn();

        int result1 = clac.plus(10,6);
        System.out.println("result1: " +result1);

        byte x = 10;
        byte y = 4;
        double result2 = clac.divide(x, y);
        System.out.println("result2: " + result2);

        clac.powerOff();
    }
}