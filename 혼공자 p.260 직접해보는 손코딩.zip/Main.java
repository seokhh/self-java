/* print 클래스에서 메소드를 생성하여 출력하는 코드를 짜보시오 */
public class Main {
    public static void main(String[] args) {

        Calculator cal = new Calculator();
        cal.execute();
    }
}