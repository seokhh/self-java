public class Calculator {
    double areaRectangle(double width){
        double area = width*width;
        return area;
    }

    double areaRectangle(double width, double height){
        double area = width * height;
        return area;
    }
}
