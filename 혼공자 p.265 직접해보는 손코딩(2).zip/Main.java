public class Main {
    public static void main(String[] args) {
        Calculator cal = new Calculator();

        double area1 = cal.areaRectangle(5);
        System.out.println("사각형1의 넓이: " + area1);
        double area2 = cal.areaRectangle(5,10);
        System.out.println("사각형2의 넓이: " + area2);
    }
}