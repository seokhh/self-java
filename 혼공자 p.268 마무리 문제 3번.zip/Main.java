/* memberservice 클래스에 메소드를 선언해서 알맞는 비밀번호와 아이디를 입력하면 로그인을 출력하는 코드를 짜보시오*/
public class Main {
    public static void main(String[] args) {
        MemberService ms = new MemberService();
        boolean result = ms.login("hong", "12345");
        if(result){
            System.out.println("로그인 되었습니다.");
            ms.logout("hong");
        } else {
            System.out.println("id 혹은 password가 잘못되었습니다.");
        }
    }
}