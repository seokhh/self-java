/* print 클래스에서 메소드를 생성하여 출력하는 코드를 짜보시오 */
public class Main {
    public static void main(String[] args) {
        Printer pr = new Printer();
        pr.println(10);
        pr.println(true);
        pr.println(7.5);
        pr.println("홍길동");
    }
}