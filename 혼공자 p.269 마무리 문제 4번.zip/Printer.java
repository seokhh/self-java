public class Printer {

    void println(int value){
        System.out.println(value);
    }

    void println(boolean value){
        System.out.println(value);
    }

    void println(double value){
        System.out.println(value);
    }

    void println(String value){
        System.out.println(value);
    }
}
