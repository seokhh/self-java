public class Main {
    public static void main(String[] args) {
        Car myCar = new Car("포르쉐");
        Car yourCar = new Car("람보르기니");

        myCar.run();
        yourCar.run();
    }
}