public class Main {
    /*static*/ int speed;
    /*static*/ void run(){
        System.out.println(speed + "으로 달립니다.");
    }
    public static void main(String[] args) {
        Main myCar = new Main();
        myCar.speed = 60;
        myCar.run();

    }
}