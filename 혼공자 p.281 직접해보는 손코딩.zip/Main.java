public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("123456-1234567", "홍길동");

        System.out.println(p1.nation);
        System.out.println(p1.ssn);
        System.out.println(p1.name);
        System.out.println();

        //p1.nation = "USA";  정적필드이기 때문에 외부에서 고칠 수 없다.
        //p1.ssn = "987654-9876543";
        p1.name = "홍삼원";

        System.out.println(p1.nation);
        System.out.println(p1.ssn);
        System.out.println(p1.name);
    }
}