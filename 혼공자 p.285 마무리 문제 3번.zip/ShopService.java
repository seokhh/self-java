public class ShopService {
    private static ShopService sse = new ShopService();

    private ShopService(){}

    static ShopService getInstance(){
        return sse;
    }
}
