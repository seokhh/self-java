package sec06.exam04.package1;

public class A {
   public A() {} // public을 빼버리면 C클래스에선 쓸 수가 없다. 패키지가 다르기 때문에
    // private는 어떠한 클래스에서도 사용이 불가하다.
    A a1 = new A(true);
    A a2 = new A(1);
    A a3 = new A("문자열");

    public A(boolean b){}
    A(int b) {}
    private A(String s){}
}
