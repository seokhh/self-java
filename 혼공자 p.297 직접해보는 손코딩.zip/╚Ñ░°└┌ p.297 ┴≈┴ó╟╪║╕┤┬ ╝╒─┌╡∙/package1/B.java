package sec06.exam04.package1;

public class B {
    A field = new A();

    A a1 = new A(true);
    A a2 = new A(1);
    A a3 = new A("문자열"); //private 생성자로 다른 클래스에서 생성 불가
}
