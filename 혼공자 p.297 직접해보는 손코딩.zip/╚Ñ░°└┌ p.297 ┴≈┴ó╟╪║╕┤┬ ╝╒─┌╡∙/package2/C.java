package sec06.exam04.package2;
import sec06.exam04.package1.*;
public class C {
    A field = new A();

    A a1 = new A(true);
    A a2 = new A(1); // default 생성자로 다른 패키지에서는 생성 불가

    A a3 = new A("문자열"); //private 생성자로 다른 클래스에서 생성 불가
}
