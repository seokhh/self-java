package sec06.exam05.package1;

public class A {
    public int field1;

    int field2;

    private int field3;


    public void method1(){
    }

    void method2(){

    }

    private void method3(){
        
    }
}
