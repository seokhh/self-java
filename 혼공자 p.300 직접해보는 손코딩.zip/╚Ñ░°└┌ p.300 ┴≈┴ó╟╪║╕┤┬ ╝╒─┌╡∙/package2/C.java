package sec06.exam05.package2;

import sec06.exam05.package1.A;

public class C {
    public C(){
        A a = new A();
        a.field1 = 10; //public으로 선언되었기 때문에 생성 가능
        a.method1(); //public으로 선언되었기 때문에 생성 가능

        a.field2 = 5; //default로 선언되었기 때문에 다른 패키지 생성 불가능
        a.method2(); //default로 선언되었기 때문에 다른 패키지 생성 불가능

        a.field3 = 1; //private로 선언되었기 때문에 다른 클래스 생성 불가능
        a.method3(); //private로 선언되었기 때문에 다른 클래스 생성 불가능
    }
    public void method(){
        A a = new A();
        a.field1 = 10; //public으로 선언되었기 때문에 생성 가능
        a.method1(); //public으로 선언되었기 때문에 생성 가능

        a.field2 = 5; //default로 선언되었기 때문에 다른 패키지 생성 불가능
        a.method2(); //default로 선언되었기 때문에 다른 패키지 생성 불가능

        a.field3 = 1; //private로 선언되었기 때문에 다른 클래스 생성 불가능
        a.method3(); //private로 선언되었기 때문에 다른 클래스 생성 불가능
    }
}
