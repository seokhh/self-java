public class Main{

    public static void main(String args[]){
        DmbCellPhone dmbCellPhone = new DmbCellPhone("아이폰","딥퍼플", 9);

        System.out.println("모델: "+ dmbCellPhone.model);
        System.out.println("색상: "+dmbCellPhone.color);
        System.out.println("채널: "+dmbCellPhone.channel);

        dmbCellPhone.poweron();
        dmbCellPhone.bell();
        dmbCellPhone.sendvoice("여보세요.");
        dmbCellPhone.recivevoice("안녕하세요! 저는 홍길동인데요.");
        dmbCellPhone.sendvoice("아 네 반갑습니다.");
        dmbCellPhone.hangup();

        dmbCellPhone.turnondmb();
        dmbCellPhone.changedmb(12);
        dmbCellPhone.turnoffdmb();

        dmbCellPhone.poweroff();
    }
}