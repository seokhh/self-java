package sec01.exam02;

public class StudentExample {
    public static void main(String[] args){
        Student student = new Student("감자바", "000000-1234567", 25);
        System.out.println("name: " + student.name);
        System.out.println("ssn: " + student.ssn);
        System.out.println("studentNo: " + student.studentNo);
    }
}
