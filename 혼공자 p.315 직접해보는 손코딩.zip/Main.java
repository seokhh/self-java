public class Main{

    public static void main(String args[]){
        Student student = new Student("석해현", "051211-1234567", 52);
        System.out.println("name: "+ student.name);
        System.out.println("ssn: "+ student.ssn);
        System.out.println("studentNo: "+ student.studentNo);
    }
}