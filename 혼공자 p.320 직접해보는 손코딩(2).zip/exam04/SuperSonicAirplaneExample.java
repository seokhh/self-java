package sec01.exam04;

public class SuperSonicAirplaneExample {
    public static void main(String[] args){
        SuperSonicAirplane superSonicAirplane = new SuperSonicAirplane();

        superSonicAirplane.takeOff();
        superSonicAirplane.fly();
        superSonicAirplane.flyMode = SuperSonicAirplane.SUPERSONIC;
        superSonicAirplane.fly();
        superSonicAirplane.flyMode = SuperSonicAirplane.NORMAL;
        superSonicAirplane.fly();
        superSonicAirplane.land();
    }
}
