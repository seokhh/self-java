public class Airplane{

    public void land(){
        System.out.println("착륙합니다. ");
    }
    public void fly(){
        System.out.println("일반 비행입니다. ");
    }
    public void takeoff(){
        System.out.println("이륙합니다. ");
    }
}