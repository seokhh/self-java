public class Main{

    public static void main(String args[]){
        Superairplane sa = new Superairplane();

        sa.takeoff();
        sa.fly();
        sa.flymode = Superairplane.SUPERSONIC;
        sa.fly();
        sa.flymode = Superairplane.NORMAL;
        sa.fly();
        sa.land();
    }
}