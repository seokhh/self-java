package sec01.exam05;

public final class Member {

}
