package sec01.exam05;

public class VIP extends Member{
// final로 선언된 Member 클래스라 상속이 안됨.
}
