package sec01.exam06;

public class SportsCar extends Car{

    @Override
    public void speedUp() {
        speed += 10;
    }
    public void stop(){
        //fianl로 선언된 메서드라 재정의가 불가하다.
    }
}
