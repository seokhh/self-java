package sec01.exam07.pack2;

import sec01.exam07.pack1.A;

public class C {
    public void method(){
        A a = new A();
        a.field = "value";
        a.method();
        //protected 접근제한은 default와 비슷하지만 다른 패키지라면 자식 클래스에만 접근을 혀용한다
        //따라서 A를 상속하지 않은 C는 사용 불가능
    }
}
