public class Child extends Parent{
    private int studentNo;

    public Child(String name, int studentNo){
        //this.name = name; 원래 이 부분이지만 부모의 있는 메서드를 호출해야하기 때문에 super를 활용해야 한다.
        super(name);
        this.studentNo = studentNo;
    }
}
