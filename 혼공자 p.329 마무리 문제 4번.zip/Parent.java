/* Parent 를 상속하는 Child 클래스가 있다. 컴파일 중 오류가 발생했는데 고치고 이유를 찾으시오*/

public class Parent {
    public String name;

    public Parent(String name){
        this.name = name;
    }
}
