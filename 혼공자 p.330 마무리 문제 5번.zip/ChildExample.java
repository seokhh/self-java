import sec01.exam07.pack2.C;

public class ChildExample {
    public static void main(String[] args){
        Child child = new Child();
    }
}


/* 출력결과
*   Parent(String nation) call
*   Parent() call
*   Child(String name) call
*   Child() call
*   */