/* Parent 를 상속받는 Child 클래스를 작성했다. Example를 실행할때 호출되는 각 클래스의 생성자의 순서를 생각하면서 출력 결과를 작성해보시오*/

public class Parent {
    public String nation;

    public Parent(){
        this("대한민국");
        System.out.println("Parent() call");
    }

    public Parent(String nation){
        this.nation = nation;
        System.out.println("Parent(String nation) call");
    }

}
