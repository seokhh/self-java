public class Main{

    public static void main(String args[]){
        Child child = new Child();

        Parent parent = child;
        parent.method1();
        parent.method2(); // Child 클래스에서 Parent 클래스에 있는 method2 를 재정의 해서 출력 값은 다르게 나옴
        child.method3(); // Parent 클래스에서 method3가 정의 되어있지 않기 때문에 Child로 출력
                         // Parent.method3로 쓰면 오류 발생
    }
}