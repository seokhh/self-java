public class Main{
    Driver driver = new Driver();
    Vehicle vehicle = new Vehicle();

    Bus bus = new Bus();
    Taxi taxi = new Taxi();

    driver.drive(bus);
    driver.drive(taxi); // 8줄과 9줄이 안되는 이유를 아직 모르겠음 강의를 보고 해도 오류가 발생함
}