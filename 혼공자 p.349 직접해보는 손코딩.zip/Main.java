public class Main {
    public static void main(String[] args) {
        Parent parent = new Child();
        parent.method1();
        parent.method2();
        //parent 클래스가 상위 클래스 child가 하위 클래스 하위클래스가 상위 클래스가 되는건 가능
        //따라서 child 클래스에 있던 method3가 사라져서 method3는 출력 불가능

        Child child = (Child) parent; //parent 객체를 형변환 시켜줬기 때문에 method3 출력 가능
        child.method3();
    }
}
