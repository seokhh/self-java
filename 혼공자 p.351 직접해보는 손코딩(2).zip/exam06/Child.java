package sec02.exam06;

public class Child extends Parent {
}
