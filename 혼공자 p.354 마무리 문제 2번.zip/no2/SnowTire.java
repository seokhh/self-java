package Chap7.problem.no2;

public class SnowTire extends Tire{

    @Override
    public void run() {
        System.out.println("스노우 타이어가 굴러갑니다.");
    }
}
