package Chap7.problem.no2;

public class SnowTireExample {
    public static void main(String[] agrs){
        SnowTire snowTire = new SnowTire();
        Tire tire = snowTire; //자동타입 변환됨

        snowTire.run();
        tire.run(); //자식객체에서 오버라이딩으로 재정의한 매서드가 쓰여짐
    }
}