/* Tire를 상속하는 SnowTire클래스를 작성했다. Example실행했을 때 출력결과를 써보시오*/

// 스노우 타이어가 굴러갑니다.
// 스노우 타이어가 굴러갑니다.

package Chap7.problem.no2;

public class Tire {
    public void run(){
        System.out.println("일반 타이어가 굴러갑니다.");
    }
}
