package Chap7.problem.no5;

public class AService extends MemberService{

    @Override
    public void login() {
        System.out.println("A 로그인");
    }
}
