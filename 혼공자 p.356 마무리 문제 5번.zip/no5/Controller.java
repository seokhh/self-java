package Chap7.problem.no5;

public class Controller {
    public MemberService service;
    public void setService(MemberService service){
        this.service = service;
    }
}
