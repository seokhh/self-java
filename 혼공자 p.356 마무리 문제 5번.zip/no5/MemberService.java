package Chap7.problem.no5;

public class MemberService extends Service{
    public void login(){
        System.out.println("멤버 로그인");
    }
}
