/* Service클래스가 선언되었다. Controller 객체를 생성하고 메소드를 호출하면 어떤 내용이 출력되는지 써보시오*/

// 멤버로그인
// A로그인

package Chap7.problem.no5;

public class Service {
    public void login(){
        System.out.println("로그인");
    }
}
