public class Main {
    public static void main(String[] args) {
        Smartphone smartphone = new Smartphone("석해현");

        smartphone.turnon(); //phone의 메서드
        smartphone.internetsearch();
        smartphone.turnoff(); //phone의 메서드
    }
}
