public class Smartphone extends Phone{
    public Smartphone(String owner){
        super(owner);
    }
    public void internetsearch(){
        System.out.println("인터넷 검색을 합니다.");
    }
}