public class Dog extends Animal{
    String kind = "강아지";
    public Dog(){
        this.kind="포유류";
    }

    @Override
    public void sound(){
        System.out.println("멍멍");
    }
}