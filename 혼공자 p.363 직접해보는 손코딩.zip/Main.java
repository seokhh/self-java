public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        Cat cat = new Cat();
        System.out.println("종류: "+dog.kind); // 종류를 출력하는걸 추가함
        dog.sound();
        System.out.println("종류: "+cat.kind); // 종류를 출력하는걸 추가함
        cat.sound();
        System.out.println("-----");

        Animal animal = null;
        animal = new Dog();
        animal.sound();
        animal = new Cat();
        animal.sound();
        System.out.println("-----");

        animalSound(new Dog());
        animalSound(new Cat());
    }
    public static void animalSound(Animal animal){
        animal.sound();
    }
}
