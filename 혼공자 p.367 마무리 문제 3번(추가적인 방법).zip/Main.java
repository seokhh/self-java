public class Main {
    public static void main(String[] args) {
        Loginservlet loginservlet = new Loginservlet();
        Fildedownloadservlet fildedownloadservlet = new Fildedownloadservlet();
        loginservlet.service();
        fildedownloadservlet.service();
        System.out.println("-----");

        Httpservlet httpservlet = null;
        httpservlet = new Loginservlet();
        httpservlet.service();
        httpservlet = new Fildedownloadservlet();
        httpservlet.service();
        System.out.println("-----");

        method(new Loginservlet());
        method(new Fildedownloadservlet());
    }
    public static void method(Httpservlet servlet){
        servlet.service();
    }
}
