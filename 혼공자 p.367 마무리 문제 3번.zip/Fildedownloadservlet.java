public class Fildedownloadservlet extends Httpservlet{
    @Override
    public void service(){
        System.out.println("파일을 다운로드합니다.");
    }
}
