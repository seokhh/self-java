public abstract class Httpservlet{

    public abstract void service();
}
