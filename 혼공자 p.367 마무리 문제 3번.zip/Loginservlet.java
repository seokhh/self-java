public class Loginservlet extends Httpservlet{
    @Override
    public void service(){
        System.out.println("로그인합니다.");
    }
}
