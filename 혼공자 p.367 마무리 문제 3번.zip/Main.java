public class Main {
    public static void main(String[] args) {
        method(new Loginservlet());
        method(new Fildedownloadservlet());
    }
    public static void method(Httpservlet servlet){
        servlet.service();
    }
}
