package Chap8.sec01.exam01;

public interface RemoteControl {

}
