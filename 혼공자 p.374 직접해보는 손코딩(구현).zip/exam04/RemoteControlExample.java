package Chap8.sec01.exam04;

public class RemoteControlExample {
    public static void main(String[] args){
        RemoteControl rc1 = new Television();
        RemoteControl rc2 = new Audio();
        //rc = new Television();
        //rc = new Audio();

        rc1.turnOn();
        rc1.setVolume(5);
        rc1.turnOff();

        rc2.turnOn();
        rc2.setVolume(7);
        rc2.turnOff();
    }
}
