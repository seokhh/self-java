public class Main {
    public static void main(String[] args) {
        Remotecontrol rc = new Audio(); //Television

        rc.turnon();
        rc.setvolume(5);
        rc.turnoff();
    }
}
