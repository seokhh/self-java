package Chap8.sec01.exam05;

public interface Searchable {
    void Search(String url);
}
