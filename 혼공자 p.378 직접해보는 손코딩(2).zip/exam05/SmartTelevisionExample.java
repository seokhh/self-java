package Chap8.sec01.exam05;

public class SmartTelevisionExample {
    public static void main(String[] agrs){

        SmartTelevision tv = new SmartTelevision();

        RemoteControl rc = tv;
        rc.turnOn();
        rc.setVolume(5);
        rc.turnOff();

        Searchable searchable = tv;
        searchable.Search("http://www.naver.com");

    }
}
