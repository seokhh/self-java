public class Main {
    public static void main(String[] args) {
        Smarttelevision st = new Smarttelevision();

        Remotecontrol rc = st;
        rc.turnon();
        rc.setvolume(7);
        rc.turnoff();

        Searchable searchable = st;
        searchable.search("http://www.naver.com");

    }
}
