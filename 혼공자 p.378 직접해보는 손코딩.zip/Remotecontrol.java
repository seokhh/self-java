public interface Remotecontrol{
    int MAX_VLOUME = 10;
    int MIN_VOLUME= 0;

    void turnon();
    void turnoff();
    void setvolume(int volume);
}