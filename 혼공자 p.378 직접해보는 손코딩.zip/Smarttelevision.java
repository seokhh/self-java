public class Smarttelevision implements Remotecontrol, Searchable{
    private int volume;
    @Override
    public void turnon() {
        System.out.println("TV를 켭니다.");
    }

    @Override
    public void turnoff() {
        System.out.println("TV를 끕니다.");
    }

    @Override
    public void setvolume(int volume) {
        if(volume>Remotecontrol.MAX_VLOUME){
            this.volume = Remotecontrol.MAX_VLOUME;
        } else if (volume < Remotecontrol.MIN_VOLUME) {
            this.volume = Remotecontrol.MIN_VOLUME;
        }
        else{
            this.volume = volume;
        }
        System.out.println("현재 TV 볼륨: "+this.volume);
    }

    @Override
    public void search(String url) {
        System.out.println(url +"을 검색합니다.");
    }
}
