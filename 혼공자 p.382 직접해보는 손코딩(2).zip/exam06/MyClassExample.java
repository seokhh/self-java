package Chap8.sec01.exam06;

public class MyClassExample {
    public static void main(String[] agrs){

        System.out.println("1)-------------------");

        MyClass myClass1 = new MyClass();
        myClass1.rc.turnOn();
        myClass1.rc.setVolume(5); //MyClass 필드에 Television으로 정의되어있어서
        // Televison의 메소드로 나타남.

        System.out.println("2)-------------------");

        MyClass myClass2 = new MyClass(new Audio());

        System.out.println("3)-------------------");

        MyClass myClass3 = new MyClass();
        myClass3.methodA();

        System.out.println("4)-------------------");

        MyClass myClass4 = new MyClass();
        myClass4.methodB(new Television());
    }
}
