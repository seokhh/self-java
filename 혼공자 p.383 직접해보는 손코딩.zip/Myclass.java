public class Myclass {
    Remotecontrol rc = new Television();

    Myclass(){

    }
    Myclass(Remotecontrol rc){
        this.rc = rc;
        rc.turnon();
        rc.setvolume(5);
    }
    void methoda(){
        Remotecontrol rc = new Audio();
        rc.turnon();
        rc.setvolume(8);
    }
    void methodb(Remotecontrol rc){
        rc.turnon();
        rc.setvolume(2);
    }
}
