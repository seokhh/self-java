package Chap8.problem.sec01.no3;

public class Cat implements Soundable{

    @Override
    public String sound() {
        return "야옹";
    }
}
