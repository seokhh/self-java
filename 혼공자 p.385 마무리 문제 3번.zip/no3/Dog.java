package Chap8.problem.sec01.no3;

public class Dog implements Soundable {

    @Override
    public String sound() {
        return "멍멍";
    }
}
