/* 인터페이스를 활용하여 멍멍 야옹 이라는 문구가 나오도록 클래스를 작성해보시오*/

package Chap8.problem.sec01.no3;

public interface Soundable {
    String sound();
}
