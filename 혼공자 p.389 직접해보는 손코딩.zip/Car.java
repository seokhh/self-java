public class Car {
    Tire frontlefttire = new Hankooktire();
    Tire frontrighttire = new Hankooktire();
    Tire backlefttire = new Hankooktire();
    Tire backrighttire = new Hankooktire();

    void run(){
        frontlefttire.roll();
        frontrighttire.roll();
        backlefttire.roll();
        backrighttire.roll();
    }
}