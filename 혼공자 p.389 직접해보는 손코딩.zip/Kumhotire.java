public class Kumhotire implements Tire{

    @Override
    public void roll() {
        System.out.println("금호 타이어가 굴러갑니다.");
    }
}