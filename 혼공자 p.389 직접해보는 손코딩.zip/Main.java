public class Main {
    public static void main(String[] args) {
        Car mycar = new Car();
        mycar.run();

        mycar.frontlefttire = new Kumhotire();
        mycar.frontrighttire = new Kumhotire();
        mycar.run();
    }
}
