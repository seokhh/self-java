public interface Tire {
    public void roll();
}