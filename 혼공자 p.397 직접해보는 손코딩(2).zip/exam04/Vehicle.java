package Chap8.sec02.exam04;

public interface Vehicle {
    public void run();
}
