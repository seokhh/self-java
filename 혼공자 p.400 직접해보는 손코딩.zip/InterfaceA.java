public interface InterfaceA{
    public void methodA();
}
