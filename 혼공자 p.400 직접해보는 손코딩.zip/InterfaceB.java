public interface InterfaceB {
    public void methodB();
}
