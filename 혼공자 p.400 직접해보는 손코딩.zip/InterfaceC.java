public interface InterfaceC extends InterfaceA, InterfaceB{
    public void methodC();
}
