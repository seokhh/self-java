package Chap8.problem.sec02.no3;

public class Dao {
    public void dbWork(DataAccessObject dao){
        dao.select();
        dao.insert();
        dao.update();
        dao.delete();
    }
}
