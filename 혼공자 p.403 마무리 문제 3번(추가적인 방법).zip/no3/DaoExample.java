/* 실행결과를 보고 인터페이스 DataAccessObject, 구현 클래스 OracleDao, MySqlDao를 만들어 보시오.*/

package Chap8.problem.sec02.no3;

public class DaoExample {

    public static void main(String[] agrs){
        Dao dao = new Dao();
        dao.dbWork(new OracleDao());
        dao.dbWork(new MySqlDao());
    }
}
