/* 실행결과를 보고 인터페이스 DataAccessObject, 구현 클래스 OracleDao, MySqlDao를 만들어 보시오.*/

package Chap8.problem.sec02.no3;

public class DaoExample {
    public static void dbWork(DataAccessObject dao){
        dao.select();
        dao.insert();
        dao.update();
        dao.delete();
    }

    public static void main(String[] agrs){
        dbWork(new OracleDao());
        dbWork(new MySqlDao());
    }
}
