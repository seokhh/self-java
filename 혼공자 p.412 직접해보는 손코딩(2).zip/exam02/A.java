package Chap9.sec01.exam02;

public class A {
    class B{}
    static class C{}

    B field1 = new B();
    C field2 = new C();

    void method1(){
        B var1 = new B();
        C var2 = new C();
    }

    //static B field3 = new B(); 인스턴스 객체라 A객체가 없어서는 안되는 B로는 생성 불가
    static C field4 = new C();
    
    static void method2(){
        //B var1 = new B(); method2는 A없어도 호출 가능한데 B는 A가 필요해서 오류 발생
        C var2 = new C();
    }
}
