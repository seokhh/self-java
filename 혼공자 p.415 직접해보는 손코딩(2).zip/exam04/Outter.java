package Chap9.sec01.exam04;

public class Outter {
    public void method1(int arg){
        int localVariable = 1;

        //arg = 100; final 특성을 가졌기때문에 값을 바꿀 수 없음
        //localVariable = 100; 위와 동일
        class Inner{
            void method(){
                int result = arg + localVariable;
            }
        }
    }
}
