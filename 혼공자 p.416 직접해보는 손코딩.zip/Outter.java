public class Outter {
    String field = "Outter - field";
    void method(){
        System.out.println("Outter - method");
    }

    class Nested{
        String field = "Nested - field";
        void method(){
            System.out.println("Nested - method");
        }

        void print(){
            System.out.println(this.field); //this는 nested 객체를 참조함
            this.method(); //위와 동일하기 때문에 nested가 호출됨

            System.out.println(Outter.this.field);
            Outter.this.method();
        }
    }
}