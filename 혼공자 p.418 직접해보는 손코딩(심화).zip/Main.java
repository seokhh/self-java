class Main{
    public static void main(String[] args){
        Button btn1 = new Button();
        btn1.setListener(new CallListner());
        btn1.click();

        Button btn2 = new Button();
        btn2.setListener(new MessageListener());
        btn2.click();
    }
}