class Main{
    public static void main(String[] args){
        Button btn = new Button();
        btn.setListener(new CallListner());
        btn.click();
    }
}