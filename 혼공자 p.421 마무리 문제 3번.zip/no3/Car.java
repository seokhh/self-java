package Chap9.problem.sec01.no3;

public class Car {
    class Tire {}
    static class Engine{ }
}
