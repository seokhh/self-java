package Chap9.problem.sec01.no3;

/* Car 내부에 Tire 와 Engine이 멤버 클래스로 선언되어 있다. 멤버 클래스의 객체를 생성하는 코드를 적어보시오*/
public class NestedClassExample {
    public static void main(String[] args){
        Car myCar = new Car();

        Car.Tire tire = myCar.new Tire();

        Car.Engine engine = new Car.Engine();
    }
}
