package Chap9.problem.sec01.no4;

/* 오류가 발생하는 곳을 고쳐보시오*/
public class Chatting {
    void startChat(String chatId){
        //String nickname = null;
        //nickname = chatId;

        String nickname = chatId;

    class Chat {
        public void start() {
            while (true) {
                String inputData = "안녕하세요.";
                String messsage = "[" + /*nickname final특성을 가지고 있기 때문에 변경할 수 없다.*/ nickname + "]" + inputData;
                sendMessage(messsage);
            }
        }

        void sendMessage(String message) {

        }
      }
      Chat chat = new Chat();
    chat.start();
    }
}
