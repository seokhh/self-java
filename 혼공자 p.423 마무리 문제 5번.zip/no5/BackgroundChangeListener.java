package Chap9.problem.sec01.no5;

public class BackgroundChangeListener implements CheckBox.OnSelectListener{

    @Override
    public void onSelect() {
        System.out.println("배경을 변경합니다.");
    }
}
