package Chap9.problem.sec01.no5;

/*CheckBox를 실행했을 때 "배경을 변경합니다." 라는 문구가 출력되게 BackgroundChangeListener 클래스를 짜보시오.*/
public class CheckBoxExample {
    public static void main(String[] args){
        CheckBox checkBox = new CheckBox();
        checkBox.setOnSelectListener(new BackgroundChangeListener());
        checkBox.select();
    }
}
