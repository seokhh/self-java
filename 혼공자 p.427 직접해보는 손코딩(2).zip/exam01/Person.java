package Chap9.sec02.exam01;

public class Person {
    void wake(){
        System.out.println("7시에 일어납니다.");
    }
}
