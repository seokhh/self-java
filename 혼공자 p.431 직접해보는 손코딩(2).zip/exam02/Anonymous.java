package Chap9.sec02.exam02;

public class Anonymous {
    RemoteControl field = new RemoteControl() {

        @Override
        public void turnOn() {
            System.out.println("TV를 켭니다.");
        }

        @Override
        public void tunrOff() {
            System.out.println("TV를 끕니다.");
        }
    };
    
    void method1(){
        RemoteControl localVarl = new RemoteControl() {
            @Override
            public void turnOn() {
                System.out.println("Audio를 켭니다.");
            }

            @Override
            public void tunrOff() {
                System.out.println("Audio를 끕니다.");
            }
        };
        localVarl.turnOn();
        localVarl.tunrOff();
    }
    
    void method2(RemoteControl rc){
        rc.turnOn();
        rc.tunrOff();
    }
}
