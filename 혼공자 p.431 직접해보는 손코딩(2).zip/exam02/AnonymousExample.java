package Chap9.sec02.exam02;

public class AnonymousExample {
    public static void main(String[] args){

        Anonymous anony = new Anonymous();

        anony.field.turnOn();
        anony.field.tunrOff();

        anony.method1();

        anony.method2(new RemoteControl() {
            @Override
            public void turnOn() {
                System.out.println("SmartTv를 켭니다.");
            }

            @Override
            public void tunrOff() {
                System.out.println("SmartTv를 끕니다.");
            }
        });
    }
}
