public class Anonymous {
  ReomteControl field = new ReomteControl() {
    @Override
    public void turnOn() {
      System.out.println("TV를 켭니다.");
    }

    @Override
    public void turnOff() {
      System.out.println("TV를 끕니다.");
    }
  };

  void  method1(){
    ReomteControl localVar = new ReomteControl() {
      @Override
      public void turnOn() {
        System.out.println("Audio를 켭니다.");
      }

      @Override
      public void turnOff() {
        System.out.println("Audio를 끕니다.");
      }
    };

    localVar.turnOn();
    localVar.turnOff();
  }

  void method2(ReomteControl rc){
      rc.turnOn();
      rc.turnOff();
  }
}
