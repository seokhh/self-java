public interface ReomteControl {
  public void turnOn();
  public void turnOff();
}
