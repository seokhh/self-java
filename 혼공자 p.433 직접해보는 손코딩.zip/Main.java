package exam03;

public class Main {
    public static void main(String[] args){
        Window w = new Window();

        w.button1.touch();

        w.button2.touch();
    }
}
