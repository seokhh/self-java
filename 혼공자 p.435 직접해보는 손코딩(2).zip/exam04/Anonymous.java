package Chap9.sec02.exam04;

public class Anonymous {
    private int field;

    public void method(int arg1, int arg2){
        int var1 = 0;
        int var2 = 0;

        //field = 10; field는 값을 변경해도 문제가 되지 않음.
        //arg1 = 10; final 특성을 가지고 있기 때문에 값 변경이 불가하다.
        Calculatable calc = new Calculatable() {
            @Override
            public int sum() {
                int result = field + arg1 + arg2 + var1 + var2;
                return result;
            }
        };

        System.out.println(calc.sum());
    }
}
