package exam04;

public class Anonymous {
    private int field = 10;
    public void method(int arg1, int arg2) {
        int var1 = 0;
        int var2 = 0;

        field = 10; /*매개변수나 로컬변수는 final특성을 가지지만
  필드는 그러한 특성을 가지지 않아서 수를 바꿔 줄 수 있음*/

        Calculatable calc = new Calculatable() {
            @Override
            public int sum() {
                int result = field + arg1 + arg2 + var1 + var2;
                return result;
            }
        };
        System.out.println(calc.sum());
    }
}
