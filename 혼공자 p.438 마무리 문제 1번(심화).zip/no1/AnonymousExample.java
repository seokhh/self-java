package Chap9.problem.sec02.no1;
/* 익명자식객체를 활용하여 디자인을합니다. 개발을 합니다. 테스트를 합니다. 라는 문구를 출력해보시오*/
public class AnonymousExample {
    public static void main(String[] args){
        Anonymous anony = new Anonymous();
        anony.field.start();
        anony.method1();
        anony.method2(new Worker(){
            void wake(){
                System.out.println("10시에 일어납니다.");
            }
            @Override
            public void start() {
                wake();
                System.out.println("테스트를 합니다.");
            }
        });
    }
}
