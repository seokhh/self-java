package Chap9.problem.sec02.no1;

public class Worker {
    public void start(){
        System.out.println("쉬고 있습니다.");
    }
}
