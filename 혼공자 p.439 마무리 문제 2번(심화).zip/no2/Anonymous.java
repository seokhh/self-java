package Chap9.problem.sec02.no2;

public class Anonymous {
    Vehicle field = new Vehicle() {
        void speed(){
            System.out.println("시속 5km/h입니다.");
        }
        @Override
        public void run() {
            System.out.println("자전거가 달립니다.");
            speed();
        }
    };
    void method1() {

        Vehicle localVar = new Vehicle() {
            void speed(){
                System.out.println("시속 80km/h입니다.");
            }
            @Override
            public void run() {
                System.out.println("승용차가 달립니다.");
                speed();
            }
        };
        localVar.run();
    }

    void method2(Vehicle vehicle){
        vehicle.run();
    }
}
