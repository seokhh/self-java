package Chap9.problem.sec02.no2;

public interface Vehicle {
    public void run();
}
