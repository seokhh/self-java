package Chap10.sec01.exam05;

public class Cat extends Animal{

}
