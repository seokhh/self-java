package Chap10.sec01.exam05;

public class ClassCastExceptionExample {
    public static void main(String[] args){

        Dog dog = new Dog();
        Animal animal = dog;
        Dog dog2 = (Dog) animal;

        Cat cat = new Cat();
        Animal animal2 = dog;
        Cat cat2 = (Cat) animal2; //animal은 dog을 참조하고 있지만 cat으로 변형해서 오류 발생

        Dog dog3 = new Dog();
        changeDog(dog3);

        Cat cat3 = new Cat();
        changeDog(cat); //dog이외에 다른 클래스로 변환할려해서 오류 발생
    }

    public static void changeDog(Animal animal){
        if(animal instanceof Dog){ //에외발생하지않도록 오류발생을 막을 수 있다.
        Dog dog = (Dog) animal;
        }
    }
}
